package com.fatec.ads;

public class Funcionario {

    protected String nome;
    protected String telefone;
    protected String senha;

    public void acessar() {
        System.out.println("Acessando sistema");
    }
}
