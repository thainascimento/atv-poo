package com.fatec.poo;

import com.fatec.poo.bean.Cliente;
import com.fatec.poo.dao.ClienteDAO;

public class Main {
    public static void main(String[] args) {
        try{
            ClienteDAO bd = new ClienteDAO();
            System.out.println("Conectado!");

            Cliente c1 = new Cliente();
            c1.setDocumento("234234234");
            c1.setEmail("n@n.com");
            c1.setNome("maria");
            c1.setTelefone("2344-2344");
            c1.setSenha("123123");

           // bd.create(c1);

           Cliente c2 = bd.read(1);
           System.out.println(c2.getCodigo() +"-"+ c2.getNome());
        }
        catch(Exception err){
            System.out.println("Ocorreu um erro "+ err.getMessage());
        }
    }
}