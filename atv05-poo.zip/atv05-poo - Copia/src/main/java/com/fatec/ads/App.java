package com.fatec.ads;

/**
 * Classe principal do programa Aqui o Java começa a executar o sistema
 */
public class App {

    public static void main(String[] args) {

        int x = 1;

        // PACIENTE 
        System.out.println("Teste Paciente");
        var p1 = new Paciente();
        p1.setCodigo(x++);
        p1.setNome("Jose da Silva");
        p1.setEmail("jose@email.com");
        p1.mostrar();

        var p2 = new Paciente(-1, null, "");
        p2.mostrar();

        // MEDICO
        System.out.println("\n Teste Medico");
        var m1 = new Medico();
        m1.setNome("Dr. Paulo");
        m1.setCrm("12345");
        m1.setTelefone("99999-9999");
        m1.setEspecialidade("Cardiologia");
        m1.setSenha("123");
        m1.mostrar();

        var m2 = new Medico(null, "", null, "", "");
        m2.mostrar();

        // RECEPCIONISTA
        System.out.println("\nTeste Recepcionista");
        var r1 = new Recepcionista();
        r1.setNome("Ana");
        r1.setCpf("111");
        r1.setTelefone("999");
        r1.setSenha("123");
        r1.mostrar();

        var r2 = new Recepcionista(null, "", null, "");
        r2.mostrar();

        // CONSULTA 
        System.out.println("\nTeste Consulta");
        var c1 = new Consulta();
        c1.setHora("10:00");
        c1.setData("2026-03-20");
        c1.setMotivo("Rotina");
        c1.setHistorico("Primeira consulta");
        c1.mostrar();

        var c2 = new Consulta(null, "", null, "");
        c2.mostrar();

        // AGENDA 
        System.out.println("\nTeste Agenda");
        var a1 = new Agenda();
        a1.setData("2026-03-21");
        a1.setHora("15:00");
        a1.setMedico("Dr. Carlos");
        a1.setPaciente("Maria");
        a1.mostrar();

        var a2 = new Agenda("", null, "", null);
        a2.mostrar();

        // EXAME 
        System.out.println("\nTeste Exame");
        var e1 = new Exame();
        e1.setConsulta("Consulta 1");
        e1.setData("2026-03-21");
        e1.setDescritivo("Exame de sangue");
        e1.mostrar();

        var e2 = new Exame(null, "", null);
        e2.mostrar();

        // RECEITA 
        System.out.println("\nTeste Receita");
        var rec1 = new Receita();
        rec1.setConsulta("Consulta 2");
        rec1.setData("2026-03-22");
        rec1.setDescritivo("Dipirona");
        rec1.mostrar();

        var rec2 = new Receita(null, "", null);
        rec2.mostrar();

        // RELACIONAMENTOS 
        System.out.println("\nTeste RELACIONAMENTOS");

        // Associação
        r1.setPaciente(p1);
        r1.setConsulta(c1);

        // Agregação
        a1.adicionarConsulta(c1);

        // Composição
        c1.adicionarReceita(rec1);
        c1.adicionarExame(e1);

        System.out.println("Relacionamentos testados com sucesso!");

    }
}
