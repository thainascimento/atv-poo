package com.fatec.ads;

public class Procedimento {

    protected String data;
    protected String descritivo;

    public void consultar() {
        System.out.println("Consultando...");
    }
}
