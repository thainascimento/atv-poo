package com.fatec.ads;

public class Receita extends Procedimento {

    public Receita(String data, String descritivo) {
        this.data = data;
        this.descritivo = descritivo;
    }

    public Receita() {
    }

    public void prescrever() {
        System.out.println("Receita prescrita");
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getDescritivo() {
        return descritivo;
    }

    public void setDescritivo(String descritivo) throws Exception {
        if (descritivo == null || descritivo.length() <= 0) {
            throw new Exception("Informe o descritivo do exame");
        }
        this.descritivo = descritivo;
    }

    public void mostrar() {
        var s = "Receita [ getData()=" + getData() + ", getDescritivo()="
                + getDescritivo() + "]";
        System.out.println(s);
    }
}
